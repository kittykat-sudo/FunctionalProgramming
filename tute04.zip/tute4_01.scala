// Scala Program for Inventory Management System
object InventoryManagementSystem {
  var itemNames = Array("apple", "banana", "orange")
  var itemQuantities = Array(5, 2, 7)

  def displayInventory(): Unit = {
    itemNames.indices.foreach(i => println(s"${itemNames(i)}: ${itemQuantities(i)}"))
  }

  def restockItem(itemName: String, quantity: Int): Unit = {
    val index = itemNames.indexOf(itemName)
    if (index != -1) {
      itemQuantities(index) += quantity
      println(s"Restocked $itemName. New quantity: ${itemQuantities(index)}")
    } else {
      println(s"$itemName does not exist in the inventory.")
    }
  }

  def sellItem(itemName: String, quantity: Int): Unit = {
    val index = itemNames.indexOf(itemName)
    if (index == -1) {
      println(s"$itemName does not exist in the inventory.")
    } else if (itemQuantities(index) < quantity) {
      println(s"Not enough stock of $itemName to sell.")
    } else {
      itemQuantities(index) -= quantity
      println(s"Sold $quantity of $itemName. Remaining: ${itemQuantities(index)}")
    }
  }

  def main(args: Array[String]): Unit = {
    displayInventory()
    restockItem("apple", 5)
    sellItem("banana", 1)
    displayInventory()
  }
}