object PatternMatchingExample extends App {
  println("Please enter an integer:")

  val input = scala.io.StdIn.readLine().toInt //toInt converts the String to an Int

// scala.io.StdIn is an object that reads input from the keyboard.
// readLine() reads a line of text from the keyboard.
// readLine() returns a String of the entered text.

  input match {
    case x if x <= 0 => println("Negative/Zero is input")
    case x if x % 2 == 0 => println("Even number is given")
    case _ => println("Odd number is given")
  }
}
