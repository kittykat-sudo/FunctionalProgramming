//part 4
object TicketProfit {
  def main(args: Array[String]): Unit = {
    def calculateProfit(ticketPrice: Double): Double = {
      val fixedCost = 500
      val costPerAttendee = 3
      val basePrice = 15
      val baseAttendance = 120

      val attendance = baseAttendance + (basePrice - ticketPrice)/5*20
      val revenue = ticketPrice * attendance
      val totalCost = fixedCost + (attendance * costPerAttendee)
      val profit = revenue - totalCost
      profit
    }

    def findOptimalTicketPrice(): Double = {
      val prices = 1 to 100 map (_ * 5) map (_ / 10.0)
      prices.maxBy(calculateProfit)
    }

    val optimalPrice = findOptimalTicketPrice()
    println(s"The optimal ticket price for maximum profit is Rs. $optimalPrice")
  }
}
