//part 3
object EmployeeSalary {
  def main(args: Array[String]): Unit = {
    def calculateSalary(normalHours: Int, otHours: Int): Double = {
      val normalRate = 250
      val otRate = 85
      val taxRate = 0.12
      val grossSalary = (normalHours * normalRate) + (otHours * otRate)
      val netSalary = grossSalary - (grossSalary * taxRate) 
      netSalary // return keyword is not necessary
    }

    val normalHours = 40
    val otHours = 30
    val takeHomeSalary = calculateSalary(normalHours, otHours)
    println(s"Take home salary: Rs. $takeHomeSalary")
  }
}