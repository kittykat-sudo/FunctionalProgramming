//part 2
object JavaToScala {
  def main(args: Array[String]): Unit = {
    var a, b, c, d = 0
    a = 2
    b = 3
    c = 4
    d = 5
    var k = 4.3f
    var g = 3.0f // Assuming g is defined

    // Evaluating expressions
    // Note: Scala doesn't support pre-decrement and post-decrement directly. We can achieve the same logic using basic operations.
    println(-(-b) * a + c * d - (-1))
    println(a)
    a += 1
    println(-2 * (g - k) + c)
    println(c)
    c += 1
    println(c)
    c = c + 1 * a
    println(c)
  }
}

