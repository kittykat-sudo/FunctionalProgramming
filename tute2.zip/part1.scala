//part 1
object VariableAssignment {
  def main(args: Array[String]): Unit = {
    var i, j, k = 2
    var m, n = 5
    var f = 12.0f
    var g = 4.0f
    var c = 'X'

    // Evaluating expressions
    val a = k + 12 * m
    val b = m / j
    val d = n % j
    val e = m / j * j
    val fExpr = f + 10 * 5 + g
    // Scala doesn't have pre-increment operator like ++i
    i += 1
    val gExpr = i * n

    println(s"a) $a")
    println(s"b) $b")
    println(s"c) $d")
    println(s"d) $e")
    println(s"e) $fExpr")
    println(s"f) $gExpr")
  }
}