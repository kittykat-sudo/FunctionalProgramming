// Scala Program for String Formatting
object StringFormattingApp {
  def toUpper(input: String): String = input.toUpperCase

  def toLower(input: String): String = input.toLowerCase

  def formatNames(name: String)(formatter: String => String): String = formatter(name)

  def main(args: Array[String]): Unit = {
    println(formatNames("Benny")(toUpper))
    println(formatNames("Niroshan")(name => name.charAt(0).toUpper + name.substring(1).toLowerCase))
    println(formatNames("Saman")(toLower))
    println(formatNames("Kumara")(name => name.substring(0, name.length - 1).toLowerCase + name.takeRight(1).toUpperCase))
  }
}