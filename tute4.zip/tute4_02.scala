// Scala Program for Pattern Matching
object PatternMatchingApp {
  def main(args: Array[String]): Unit = {
    val input = if (args.length > 0) args(0).toInt else 0

    input match {
      case x if x <= 0 => println("Negative/Zero is input")
      case x if x % 2 == 0 => println("Even number is given")
      case _ => println("Odd number is given")
    }
  }
}